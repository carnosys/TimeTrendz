document.addEventListener('DOMContentLoaded', () => {
    const cartSidebar = document.getElementById('cart-sidebar');
    const cartToggleBtn = document.getElementById('cart-toggle-btn');
    const cartItemsList = document.getElementById('cart-items');
    const cartCountElement = document.getElementById('cart-count');
    const couponInput = document.getElementById('coupon-input');
    const applyCouponBtn = document.getElementById('apply-coupon-btn');
    const cartTotalElement = document.getElementById('cart-total');
    const payBtn = document.getElementById('pay-btn');
    const productList = document.querySelector('.product-list');
    const cartCloseBtn = document.getElementById('cart-close-btn');

    let cartItems = [];
    let discount = 0;
    let useCapture = false; // Toggle between bubbling/capturing

    // 1. Event Logging with Timestamp
    function logEvent(message) {
        const timestamp = new Date().toLocaleString();
        console.log(`[${timestamp}] ${message}`);
    }

    // 2. Toggle Cart Sidebar
    cartToggleBtn.addEventListener('click', () => {
        cartSidebar.classList.toggle('open');
        logEvent('Toggled cart sidebar');
    });

    // Close button to hide the cart sidebar
    cartCloseBtn.addEventListener('click', () => {
        cartSidebar.classList.remove('open');
        logEvent('Closed cart sidebar using close button');
    });

    // 3. Toggle Bubbling/Capturing Mode
    const propagationToggle = document.getElementById('propagation-toggle');
    propagationToggle.addEventListener('click', () => {
        useCapture = !useCapture;
        propagationToggle.textContent = useCapture ? 
            "Switch to Bubbling Mode" : "Switch to Capturing Mode";
        logEvent(`Event propagation mode changed to: ${useCapture ? 'Capturing' : 'Bubbling'}`);
        
        // Rebind the event listener with new capture mode
        productList.removeEventListener('click', handleProductClick, !useCapture);
        productList.addEventListener('click', handleProductClick, useCapture);
    });

    // 4. Event Delegation for "Add to Cart" (with Propagation Logging)
    function handleProductClick(event) {
        // Log propagation details as required
        console.log('--- Propagation Path ---');
        console.log('Event Path:', event.composedPath());
        console.log('Target:', event.target);
        console.log('Current Target:', event.currentTarget);

        if (event.target.classList.contains('add-to-cart-btn')) {
            const itemCard = event.target.closest('.item-card');
            const img = itemCard.querySelector('.item-img').src;
            const name = itemCard.querySelector('.name').textContent;
            const priceText = itemCard.querySelector('.price').textContent;
            const numericPrice = extractPriceNumber(priceText);

            cartItems.push({ imgSrc: img, name, priceNumber: numericPrice });
            updateCartDisplay();
            logEvent(`Added to cart: ${name}, price ${numericPrice}`);
        }
    }

    // Initial event binding
    productList.addEventListener('click', handleProductClick, useCapture);

    // 5. Remove Items (with stopPropagation)
    cartItemsList.addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-from-cart-btn')) {
            e.stopPropagation(); // Prevent parent events
            const index = e.target.getAttribute('data-index');
            const removedItem = cartItems[index];
            cartItems.splice(index, 1);
            updateCartDisplay();
            logEvent(`Removed from cart: ${removedItem.name}`);
        }
    });

    // 6. Update Cart UI
    function updateCartDisplay() {
        cartItemsList.innerHTML = ''; 
        cartItems.forEach((item, index) => {
            const li = document.createElement('li');
            li.className = 'cart-item';
            li.innerHTML = `
                <img src="${item.imgSrc}" alt="${item.name}">
                <div class="cart-item-info">
                    <p>${item.name}</p>
                    <p>Rs.${item.priceNumber}</p>
                </div>
                <button class="remove-from-cart-btn" data-index="${index}">Remove</button>
            `;
            cartItemsList.appendChild(li);
        });

        const total = cartItems.reduce((sum, item) => sum + item.priceNumber, 0);
        cartTotalElement.textContent = `Rs.${(total * (1 - discount)).toFixed(2)}`;
        cartCountElement.textContent = cartItems.length;
    }

    // 7. Coupon Handling
    applyCouponBtn.addEventListener('click', () => {
        const code = couponInput.value.trim();
        if (code.toUpperCase() === 'SAVE10') {
            discount = 0.10;
            logEvent('Coupon applied: SAVE10 (10% off)');
        } else {
            discount = 0;
            logEvent(`Invalid coupon code: "${code}"`);
        }
        updateCartDisplay();
    });

    // 8. Pay Button
    payBtn.addEventListener('click', () => {
        logEvent('Pay button clicked. Proceed to payment flow...');
        alert('Thank you for your purchase!');
        cartItems = [];
        discount = 0;
        updateCartDisplay();
    });

    // 9. Helper: Extract Price
    function extractPriceNumber(priceText) {
        return parseFloat(priceText.replace(/[^0-9]/g, ''));
    }
});
